import React from 'react'
import { Route, Switch } from 'react-router-dom';
import Jugador from '../containers/Jugador/Jugador';

export default function Routes() {
  
  return (null)
}
