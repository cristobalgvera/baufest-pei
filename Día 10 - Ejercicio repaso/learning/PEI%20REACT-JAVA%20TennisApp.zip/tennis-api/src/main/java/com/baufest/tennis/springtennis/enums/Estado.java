package com.baufest.tennis.springtennis.enums;

public enum Estado {
	EN_CURSO, NO_INICIADO, FINALIZADO;
}
