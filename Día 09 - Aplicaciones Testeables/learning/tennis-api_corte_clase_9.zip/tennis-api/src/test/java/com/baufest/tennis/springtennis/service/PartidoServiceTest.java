package com.baufest.tennis.springtennis.service;

import com.baufest.tennis.springtennis.mapper.JugadorMapper;
import com.baufest.tennis.springtennis.mapper.PartidoMapper;
import com.baufest.tennis.springtennis.mapper.PartidoMapperImpl;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class PartidoServiceTest {

//    PartidoMapper mapper = new PartidoMapperImpl(JugadorMapper.INSTANCE);

}
