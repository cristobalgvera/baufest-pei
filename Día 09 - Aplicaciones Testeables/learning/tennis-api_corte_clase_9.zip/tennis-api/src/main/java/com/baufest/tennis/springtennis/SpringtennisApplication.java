package com.baufest.tennis.springtennis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringtennisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringtennisApplication.class, args);
	}

}
