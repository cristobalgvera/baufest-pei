package com.baufest.test.tip5;


import java.time.LocalDate;

public class Product {
    private Long id;
    private String description;
    private LocalDate validFrom;
    private LocalDate validTo;

    public Product(String description, LocalDate validFrom, LocalDate validTo) {
        this.description = description;
        this.validFrom = validFrom;
        this.validTo = validTo;
    }

    public Product(Long id, String description, LocalDate validFrom, LocalDate validTo) {
        this.description = description;
        this.validFrom = validFrom;
        this.validTo = validTo;
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(LocalDate validFrom) {
        this.validFrom = validFrom;
    }

    public LocalDate getValidTo() {
        return validTo;
    }

    public void setValidTo(LocalDate validTo) {
        this.validTo = validTo;
    }
}
