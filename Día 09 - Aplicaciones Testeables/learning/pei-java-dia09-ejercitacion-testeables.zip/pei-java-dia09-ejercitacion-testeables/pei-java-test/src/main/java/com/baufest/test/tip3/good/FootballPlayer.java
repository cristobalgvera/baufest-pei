package com.baufest.test.tip3.good;

public class FootballPlayer implements IPlayer, IShoot, ITackle {

    public double stamina;

    public FootballPlayer() {
        this.stamina = 100;
    }
    @Override
    public void walk() {
        this.stamina -= 2;
    }
    @Override
    public void run() {
        this.stamina -= 10;
    }
    @Override
    public void shoot() {
        this.stamina -= 15;
    }
    @Override
    public void tackle() {
        this.stamina -= 10;
    }
}
