package com.baufest.test.tip3.good;

public interface IPlayer {
    void walk();
    void run();
}
