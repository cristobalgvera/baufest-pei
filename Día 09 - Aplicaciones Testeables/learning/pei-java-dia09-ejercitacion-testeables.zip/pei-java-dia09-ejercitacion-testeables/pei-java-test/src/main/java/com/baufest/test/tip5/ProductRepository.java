package com.baufest.test.tip5;

public interface ProductRepository {
    Product findById(Long id);
    void save(Product product);
}
