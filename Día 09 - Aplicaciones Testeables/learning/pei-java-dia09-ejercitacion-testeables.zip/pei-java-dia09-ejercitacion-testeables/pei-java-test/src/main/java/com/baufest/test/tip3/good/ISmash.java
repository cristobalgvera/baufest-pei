package com.baufest.test.tip3.good;

public interface ISmash {
    void smash();
}
