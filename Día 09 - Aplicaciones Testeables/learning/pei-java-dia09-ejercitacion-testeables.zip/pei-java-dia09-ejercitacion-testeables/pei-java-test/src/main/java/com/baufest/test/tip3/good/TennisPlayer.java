package com.baufest.test.tip3.good;

public class TennisPlayer implements IPlayer, IDrive, ISmash{

    public double stamina;

    public TennisPlayer() {
        this.stamina = 100;
    }
    @Override
    public void walk() {
        this.stamina -= 1;
    }
    @Override
    public void run() {
        this.stamina -= 5;
    }
    @Override
    public void drive() {
        this.stamina -= 3;
    }
    @Override
    public void smash() {
        this.stamina -= 8;
    }
}
