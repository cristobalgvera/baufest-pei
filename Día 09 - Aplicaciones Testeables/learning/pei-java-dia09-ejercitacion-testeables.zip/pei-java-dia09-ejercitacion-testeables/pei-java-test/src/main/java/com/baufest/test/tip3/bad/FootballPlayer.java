package com.baufest.test.tip3.bad;

public class FootballPlayer extends Player {

    @Override
    public void walk() {
        this.stamina -= 2;
    }

    @Override
    public void run() {
        this.stamina -= 10;
    }

    @Override
    public void shoot() {
        this.stamina -= 15;
    }

    @Override
    public void tackle() {
        this.stamina -= 10;
    }

    @Override
    public void drive() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void smash() {
        throw new UnsupportedOperationException();
    }
}
