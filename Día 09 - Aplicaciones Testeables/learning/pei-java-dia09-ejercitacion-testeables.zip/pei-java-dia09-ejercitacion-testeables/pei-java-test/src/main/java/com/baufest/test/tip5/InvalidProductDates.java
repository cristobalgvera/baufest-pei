package com.baufest.test.tip5;

public class InvalidProductDates extends RuntimeException {
}
