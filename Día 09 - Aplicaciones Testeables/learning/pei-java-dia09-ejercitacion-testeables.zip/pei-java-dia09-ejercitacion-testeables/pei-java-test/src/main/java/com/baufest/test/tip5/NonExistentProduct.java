package com.baufest.test.tip5;

public class NonExistentProduct extends RuntimeException {
}
