package com.baufest.test.tip1.good;

//import com.baufest.test.logger.CloudLogger;
import com.baufest.test.logger.FileLogger;
import com.baufest.test.logger.Logger;

public class Application {

    private Logger logger;

    public Application() {
        this.logger = new FileLogger();
        //this.logger = new CloudLogger();
    }

    String[] getLast10LoggedMessages() {
        return logger.getLast10Messages();
    }
}
