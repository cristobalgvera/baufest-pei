package com.baufest.test.tip3.good;

public interface IDrive {
    void drive();
}
