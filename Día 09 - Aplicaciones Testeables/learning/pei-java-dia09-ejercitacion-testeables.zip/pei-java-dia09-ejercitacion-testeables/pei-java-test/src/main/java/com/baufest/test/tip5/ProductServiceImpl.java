package com.baufest.test.tip5;

public class ProductServiceImpl implements ProductService {
    private final ProductRepository productRepository;

    public ProductServiceImpl(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public Product getProduct(Long id){
        Product existingProduct = this.productRepository.findById(id);
        if(existingProduct==null){
            throw new NonExistentProduct();
        }
        return existingProduct;
    }

}
