package com.baufest.test.tip5;

public interface ProductService {
    Product getProduct(Long id);
}
