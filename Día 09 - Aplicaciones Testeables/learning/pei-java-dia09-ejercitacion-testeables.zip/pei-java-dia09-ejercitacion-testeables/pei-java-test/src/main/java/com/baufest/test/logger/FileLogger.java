package com.baufest.test.logger;

import org.springframework.stereotype.Component;

@Component
public class FileLogger implements Logger {

    @Override
    public void logMessage(String message) {
        // Log message here...
    }

    @Override
    public String[] getLast10Messages() {
        // Fetch messages from file...
        return new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
    }
}
