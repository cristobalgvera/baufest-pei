package com.baufest.test.tip5;

public class InvalidProductRequiredFields extends RuntimeException {
}
