package com.baufest.test.logger;

import org.springframework.stereotype.Component;

@Component
public class CloudLogger implements Logger {

    @Override
    public void logMessage(String message) {
        // Log message here...
    }

    @Override
    public String[] getLast10Messages() {
        // Fetch messages from cloud...
        return new String[]{"11", "12", "13", "14", "15", "16", "17", "18", "19", "20"};
    }
}
