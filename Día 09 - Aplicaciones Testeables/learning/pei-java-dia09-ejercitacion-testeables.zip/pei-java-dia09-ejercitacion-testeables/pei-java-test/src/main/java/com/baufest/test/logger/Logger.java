package com.baufest.test.logger;

public interface Logger {

    void logMessage(String message);

    String[] getLast10Messages();
}
