package com.baufest.test.tip3.bad;


public class TennisPlayer extends Player {

    @Override
    public void walk() {
        this.stamina -= 1;
    }

    @Override
    public void run() {
        this.stamina -= 5;
    }

    @Override
    public void shoot() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void tackle() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void drive() {
        this.stamina -= 3;
    }

    @Override
    public void smash() {
        this.stamina -= 8;
    }
}
