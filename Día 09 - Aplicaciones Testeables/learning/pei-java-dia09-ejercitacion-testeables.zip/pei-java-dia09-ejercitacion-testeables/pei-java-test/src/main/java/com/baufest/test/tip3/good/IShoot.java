package com.baufest.test.tip3.good;

public interface IShoot {
    void shoot();
}
