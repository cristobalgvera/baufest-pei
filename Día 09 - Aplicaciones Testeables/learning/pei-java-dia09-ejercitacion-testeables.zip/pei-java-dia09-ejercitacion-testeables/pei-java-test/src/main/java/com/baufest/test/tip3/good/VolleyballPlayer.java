package com.baufest.test.tip3.good;

public class VolleyballPlayer implements IPlayer, ISmash {
    public double stamina;

    public VolleyballPlayer() {
        this.stamina = 100;
    }

    @Override
    public void walk() {
        this.stamina -= 0.5;
    }

    @Override
    public void run() {
        this.stamina -= 3;
    }

    @Override
    public void smash() {
        this.stamina -= 11;
    }
}
