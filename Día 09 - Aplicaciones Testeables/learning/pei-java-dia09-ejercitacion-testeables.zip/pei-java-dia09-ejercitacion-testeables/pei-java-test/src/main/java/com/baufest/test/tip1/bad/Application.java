package com.baufest.test.tip1.bad;

import com.baufest.test.logger.CloudLogger;
import com.baufest.test.logger.FileLogger;

public class Application {

    public String[] getLast10LoggedMessagesFromFile() {
        FileLogger fileLogger = new FileLogger();

        // Fetch messages from file...
        return fileLogger.getLast10Messages();
    }

    public String[] getLast10LoggedMessagesFromCloud() {
        CloudLogger cloudLogger = new CloudLogger();

        // Fetch messages from cloud...
        return cloudLogger.getLast10Messages();
    }
}
