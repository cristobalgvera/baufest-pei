package com.baufest.test.tip2;

import com.baufest.test.logger.Logger;

public class Application {

    private Logger logger;

    Application(Logger logger) {
        this.logger = logger;
    }

    String[] getLast10LoggedMessages() {
        return logger.getLast10Messages();
    }
}
