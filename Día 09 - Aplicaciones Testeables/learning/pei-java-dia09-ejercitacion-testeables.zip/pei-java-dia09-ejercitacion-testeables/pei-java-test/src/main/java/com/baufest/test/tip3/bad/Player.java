package com.baufest.test.tip3.bad;

public abstract class Player {

    public double stamina;

    public abstract void walk();

    public abstract void run();

    public abstract void shoot();

    public abstract void tackle();

    public abstract void drive();

    public abstract void smash();
}
