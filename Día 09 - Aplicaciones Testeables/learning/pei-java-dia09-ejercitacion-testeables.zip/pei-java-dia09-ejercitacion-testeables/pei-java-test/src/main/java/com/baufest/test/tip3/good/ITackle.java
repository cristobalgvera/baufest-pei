package com.baufest.test.tip3.good;

public interface ITackle {
    void tackle();
}
