package com.baufest.test.tip5;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SpyTest {

    @Spy
    List<String> spyOnList = new ArrayList<>();

    @Test
    void addValidProduct(){
        spyOnList.add("");
        spyOnList.add("");

        assertEquals(2, spyOnList.size());
        verify(spyOnList, times(2)).add("");
        when(spyOnList.size()).thenReturn(84);
        assertEquals(84,spyOnList.size());
    }
}
