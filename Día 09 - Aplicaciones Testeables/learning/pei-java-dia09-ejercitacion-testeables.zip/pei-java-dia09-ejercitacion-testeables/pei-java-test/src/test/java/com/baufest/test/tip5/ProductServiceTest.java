package com.baufest.test.tip5;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Test
    void getExistingProduct() {

        // Set up de precondiciones incluyendo el set up de los objetos mock
        LocalDate validFrom = LocalDate.of(2018, 1, 1);
        LocalDate validTo = LocalDate.of(2019, 1, 1);
        Product product = new Product("Headset Logitech Pro X", validFrom, validTo);
        ProductRepository productRepository = mock(ProductRepository.class);
        when(productRepository.findById(1L)).thenReturn(product);

        // Inyectar los mocks de dependencias
        ProductServiceImpl service = new ProductServiceImpl(productRepository);

        //Ejecutar el codigo a testear
        Product result = service.getProduct(1L);

        // Realizar asserts sobre los resultados esperados
        assertEquals(product.getId(),result.getId());
        assertEquals(product.getDescription(),result.getDescription());
        assertEquals(product.getValidFrom(),result.getValidFrom());
        assertEquals(product.getValidTo(),result.getValidTo());

        // Verificar que el mock fue llamado la cantidad de veces y con los parametros esperados
        verify(productRepository,times(1)).findById(1L);
    }

    @Test()
    void getNonExistentProduct() {
        // Set up de precondiciones incluyendo el set up de los objetos mock
        ProductRepository productRepository = mock(ProductRepository.class);
        when(productRepository.findById(1L)).thenReturn(null);

        // Inyectar los mocks de dependencias
        ProductServiceImpl service = new ProductServiceImpl(productRepository);

        // Ejecutar el codigo a testear y Realizar asserts sobre los resultados esperados
        assertThrows(NonExistentProduct.class, () -> service.getProduct(1L));

        // Verificar que el mock fue llamado la cantidad de veces y con los parametros esperados
        verify(productRepository,times(1)).findById(1L);
    }
}
