package com.baufest.test.tip5;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceRefactorTest {

    @Mock
    ProductRepository productRepository;

    @InjectMocks
    ProductServiceImpl service;

    @Test
    void getExistingProduct() {
        // Set up de precondiciones incluyendo el set up de los objetos mock
        LocalDate validFrom = LocalDate.of(2018, 1, 1);
        LocalDate validTo = LocalDate.of(2019, 1, 1);
        Product product = new Product("Headset Logitech Pro X", validFrom, validTo);
        when(productRepository.findById(1L)).thenReturn(product);

        //Ejecutar el codigo a testear
        Product result = service.getProduct(1L);

        // Realizar asserts sobre los resultados esperados
        assertEquals(product.getId(),result.getId());
        assertEquals(product.getDescription(),result.getDescription());
        assertEquals(product.getValidFrom(),result.getValidFrom());
        assertEquals(product.getValidTo(),result.getValidTo());

        // Verificar que el mock fue llamado la cantidad de veces y con los parametros esperados
        verify(productRepository,times(1)).findById(1L);
    }

}
