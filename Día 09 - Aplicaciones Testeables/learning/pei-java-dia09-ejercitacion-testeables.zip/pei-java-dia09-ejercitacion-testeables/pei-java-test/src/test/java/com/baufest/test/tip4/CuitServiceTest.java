package com.baufest.test.tip4;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CuitServiceTest {

    CuitService service;

    @BeforeEach
    public void init() {
        service = new CuitService();
    }

    @Test
    void cuitValido() {
        //Setup de precondiciones
        String cuit = "30-69756612-7";

        //Ejecutar el código a testear
        boolean result = service.validateCuit(cuit);

        //Realizar asserts sobre los resultados esperados
        assertTrue(result);
    }

    @Test
    void cuitInvalido() {
        //Setup de precondiciones
        String cuit = "30-697566122-7";

        //Ejecutar el código a testear
        boolean result = service.validateCuit(cuit);

        //Realizar asserts sobre los resultados esperados
        assertFalse(result);
    }
}
