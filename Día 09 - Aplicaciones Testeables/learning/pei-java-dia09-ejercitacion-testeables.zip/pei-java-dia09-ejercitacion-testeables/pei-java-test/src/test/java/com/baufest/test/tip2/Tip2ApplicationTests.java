package com.baufest.test.tip2;

import com.baufest.test.logger.CloudLogger;
import com.baufest.test.logger.FileLogger;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Tip2ApplicationTests {

    @Test
    public void shouldGetLast10LoggedMesssagesFromFile() throws Exception {
        Application application = new Application(new FileLogger());

        String[] messages = application.getLast10LoggedMessages();
        assertEquals(10, messages.length,
                "Tiene que haber una longitud de 10 mensajes desde el file pero no la hay");
    }

    @Test
    public void shouldGetLast10LoggedMesssagesFromCloud() throws Exception {
        Application application = new Application(new CloudLogger());

        String[] messages = application.getLast10LoggedMessages();
        assertEquals(10, messages.length,
                "Tiene que haber una longitud de 10 mensajes desde el cloud pero no la hay");
    }
}
