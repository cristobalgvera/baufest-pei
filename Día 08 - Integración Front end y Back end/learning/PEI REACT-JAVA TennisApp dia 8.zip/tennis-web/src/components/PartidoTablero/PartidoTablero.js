import React, { useState } from 'react';
import { Table, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom'

//Mientras no haya conexion con el back se usaran estos datos
let datosTablero = {
  id:1,
  estado: 'EN_CURSO',
  jugadorLocal: {id: 1, nombre:'Federer'},
  jugadorVisitante: {id: 2, nombre:'Nadal'},
  puntosGameActualLocal:0,
  cantidadGamesLocal:0,
  puntosGameActualVisitante:0,
  cantidadGamesVisitante:0
}

const PartidoTablero = props => {

  const [partido,setPartido] = useState(datosTablero);

  const sumarPunto = async(id, modoJugador) => {
    if(modoJugador==='LOCAL')
    {
      let puntos = partido.puntosGameActualLocal +1;
      setPartido({...partido, puntosGameActualLocal: puntos });
    }
    else{
      let puntos = partido.puntosGameActualVisitante +1;
      setPartido({...partido, puntosGameActualVisitante: puntos });
    }
  }

  return (
    <div className="container mt-4">
      <h1>Tablero</h1>
      <Table>
        <thead>
          <tr>
            <th>Jugador</th>
            <th>Puntos</th>
            <th>Games</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{partido.jugadorLocal.nombre}</td>
            <td>{partido.puntosGameActualLocal}</td>
            <td>{partido.cantidadGamesLocal}</td>
            <td>
              {partido.estado!=='FINALIZADO' &&
                <Button variant="primary" size="sm" onClick={()=>sumarPunto(partido.id, 'LOCAL')}>Sumar punto</Button>
              }
            </td>
          </tr>
          <tr>
            <td>{partido.jugadorVisitante.nombre}</td>
            <td>{partido.puntosGameActualVisitante}</td>
            <td>{partido.cantidadGamesVisitante}</td>
            <td>
              {partido.estado!=='FINALIZADO' &&
                <Button variant="primary" size="sm" onClick={()=>sumarPunto(partido.id, 'VISITANTE')}>Sumar punto</Button>    
              }
            </td>
          </tr>
        </tbody>
      </Table>
      <Link to='/partidos'>
       <Button variant="primary" className="mr-2">Volver</Button>
      </Link>
    </div>
  );
}

export default PartidoTablero;