package com.baufest.tennis.springtennis.enums;

public enum ModoJugador {
	LOCAL, VISITANTE;
}
